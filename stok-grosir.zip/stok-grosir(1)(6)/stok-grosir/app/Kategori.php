<?php
namespace App;

class Kategori extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "select * from kategoris";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }

        return $data;
    }   

    public function insert(){
        $nama = $_POST['nama'];
        $sql = "INSERT INTO kategoris VALUES ('', '$nama')";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM kategoris WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }   

    public function update($id){
        $nama = $_POST['nama'];
        
        $sql = "UPDATE kategoris SET nama = '$nama' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM kategoris WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}