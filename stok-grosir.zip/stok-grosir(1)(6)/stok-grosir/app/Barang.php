<?php
namespace App;

class Barang extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "select * from barangs";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }

        return $data;
    }   

    public function getKategori($id){
        $sql = "SELECT * FROM kategoris WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    } 

    public function insert(){
        $nama = $_POST['nama'];
        $kategori_id = $_POST['kategori_id'];
        $sql = "INSERT INTO barangs VALUES ('', '$nama', '$kategori_id')";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM barangs WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }   

    public function update($id){
        $nama = $_POST['nama'];
        $kategori_id = $_POST['kategori_id'];
        $sql = "UPDATE barangs SET nama = '$nama', kategori_id = '$kategori_id' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM barangs WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}