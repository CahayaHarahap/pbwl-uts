<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo ASSET; ?>css/style.css">
    <title>App Stok Grosir</title>
</head>

<?php
     require_once "config.php";

     if (isset($_POST['logout'])) {
         $auth = new App\Auth();
         $auth->logout();
        header("location:index.php");

     }
?>

<body>
    <nav id="navbar">
        <div class="container">
            <div class="navbar-logo">App Stok Grosir</div>
            <ul>
                <a href="index.php">
                    <li>Beranda</li>
                </a>
                <a href="index.php?page=index_kategori">
                    <li style="margin-left: 30px">Kategori</li>
                </a>
                <a href="index.php?page=index_barang">
                    <li style="margin-left: 30px">Barang</li>
                </a>
                <a href="index.php?page=index_barang_masuk">
                    <li style="margin-left: 30px">Barang Masuk</li>
                </a>
                <a href="index.php?page=index_barang_keluar">
                    <li style="margin-left: 30px">Barang Keluar</li>
                </a>
                <li style="margin-left: 30px">
                    <form method="POST">
                        <button name="logout" class="logout-button">
                            Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </nav>

    <section>
        <?php
            if (isset($_GET['page'])) 
                include 'pages/'. $_GET['page'] . ".php";
            else
                include "pages/dashboard.php";            
        ?>
    </section>

    <footer>
        &copy; Copyright Nur Cahaya Harahap | Tugas UTS Pemograman Web Dasar
    </footer>
</body>
</html>