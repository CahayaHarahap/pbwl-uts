<?php
    require_once "config.php";

    $barang = new App\Barang();
    $rows = $barang->index();

    if (isset($_POST['hapus'])) {
        $barang->delete();
        header("location:index.php?page=index_barang");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 900px">
        <div class="card-title">Data barang</div>
        <a href="index.php?page=tambah_barang">
            <button class="btn btn-success">Tambah</button>
        </a>
        <p></p>
        <table>
            <tr>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
            <?php
                $kategori = $barang->getKategori($row['kategori_id']);    
            ?>
            <tr>
                <td><?php echo $row['nama'] ?></td>
                <td><?php echo $kategori['nama'] ?></td>
                <td style="width: 25%">
                <a href="index.php?page=edit_barang&id=<?php echo $row['id']?>">
                    <button class="btn btn-warning">Edit</button>
                </a>
                <form method="POST" style="display: inline">
                    <input type="text" name="id" value="<?php echo $row['id'] ?>" style="display:none">
                    <button class="btn btn-danger" name="hapus">Hapus</button>
                </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>