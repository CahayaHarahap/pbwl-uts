<?php
    require_once "config.php";
    $barang_masuk = new App\BarangMasuk();
    $data_barang_masuk = $barang_masuk->index();
    
    if (isset($_POST['simpan'])) {
        $barang_keluar = new App\BarangKeluar();
        $barang_keluar->insert();
        header("location:index.php?page=index_barang_keluar");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Barang Masuk</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Barang Masuk</label>
                <select name="barang_masuk_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_barang_masuk as $item) { ?>
                    <option value="<?php echo $item['id'] ?>">
                        <?php 
                            $barang = $barang_masuk->getBarang($item['barang_id']);
                        ?>
                        <?php echo $barang['nama'] ?> - <?php echo $item['tgl_masuk'] ?>
                    </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Tanggal Keluar</label>
                <input type="date" name="tgl_keluar" value="<?php echo $row['tgl_keluar'] ?>">
            </div>

            <div class="form-group">
                <label for="">Jumlah</label>
                <input type="number" name="jumlah">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>