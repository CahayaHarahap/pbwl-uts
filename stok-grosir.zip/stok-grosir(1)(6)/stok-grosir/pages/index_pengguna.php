<?php
    require_once "config.php";

    $pengguna = new App\Pengguna();
    $rows = $pengguna->index();

    if (isset($_POST['hapus'])) {
        $pengguna->delete();
        header("location:index.php?page=index_pengguna");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 800px">
        <div class="card-title">Data Pengguna</div>
        <a href="index.php?page=tambah_pengguna">
            <button class="btn btn-success">Tambah</button>
        </a>
        <p></p>
        <table>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
            <tr>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td style="width: 25%">
                <a href="index.php?page=edit_pengguna&id=<?php echo $row['id']?>">
                    <button class="btn btn-warning">Edit</button>
                </a>
                <form method="POST" style="display: inline">
                    <input type="text" name="id" value="<?php echo $row['id'] ?>" style="display:none">
                    <button class="btn btn-danger" name="hapus">Hapus</button>
                </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>