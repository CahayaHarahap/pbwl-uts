<?php
    require_once "config.php";

    if (isset($_POST['simpan'])) {
        $pengguna = new App\Pengguna();
        $rows = $pengguna->insert();
        header("location:index.php?page=index_pengguna");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Pengguna</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="name">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" name="email">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="password" name="password">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>