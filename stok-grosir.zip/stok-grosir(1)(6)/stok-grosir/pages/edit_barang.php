<?php
    require_once "config.php";

    $barang = new App\Barang();
    $row = $barang->edit($_GET['id']);

    $kategori = new App\Kategori();
    $data_kategori = $kategori->index();

    if (isset($_POST['simpan'])) {
        $barang->update($_GET['id']);
        header("location:index.php?page=index_barang");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Pelanggan</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="nama" value="<?php echo $row['nama'] ?>">
            </div>
            <div class="form-group">
                <label for="">Kategori</label>
                <select name="kategori_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_kategori as $item) { ?>
                    <option value="<?php echo $item['id'] ?>"
                        <?php if ($item['id'] == $row['kategori_id']) { ?>
                            selected
                        <?php } ?>
                    >
                        <?php echo $item['nama'] ?>
                    </option>
                    <?php } ?>
                </select>
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>