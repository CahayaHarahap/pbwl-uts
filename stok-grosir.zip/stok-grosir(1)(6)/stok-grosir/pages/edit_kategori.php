<?php
    require_once "config.php";

    $kategori = new App\Kategori();
    $row = $kategori->edit($_GET['id']);

    if (isset($_POST['simpan'])) {
        $rows = $kategori->update($_GET['id']);
        header("location:index.php?page=index_kategori");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data kategori</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="nama" value="<?php echo $row['nama'] ?>">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>